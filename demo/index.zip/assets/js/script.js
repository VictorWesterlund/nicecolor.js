import { NiceColor } from "./module/NiceColor.mjs";

const niceColor = new NiceColor();

document.body.style.setProperty("--color",niceColor.get());
document.getElementById("color").innerText = niceColor.get();